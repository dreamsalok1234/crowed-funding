import { Component } from '@angular/core';

@Component({
  selector: 'app-layout',
  template: '<router-outlet><spinner></spinner></router-outlet>'
})
export class AuthLayoutComponent {}
