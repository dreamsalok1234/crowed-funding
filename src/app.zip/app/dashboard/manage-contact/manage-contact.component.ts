import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-contact',
  template: '<router-outlet><spinner></spinner></router-outlet>'
})
export class ManageContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
