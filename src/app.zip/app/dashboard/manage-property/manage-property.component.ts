import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-property',
  template: '<router-outlet><spinner></spinner></router-outlet>'
})
export class ManagePropertyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
