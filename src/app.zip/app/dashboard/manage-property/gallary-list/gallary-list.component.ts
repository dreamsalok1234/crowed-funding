import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallary-list',
  templateUrl: './gallary-list.component.html',
  styleUrls: ['./gallary-list.component.css']
})
export class GallaryListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
