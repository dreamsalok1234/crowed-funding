import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-property-summary-list',
  templateUrl: './property-summary-list.component.html',
  styleUrls: ['./property-summary-list.component.css']
})
export class PropertySummaryListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
