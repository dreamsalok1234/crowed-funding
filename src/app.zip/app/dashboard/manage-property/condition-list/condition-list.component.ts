import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-condition-list',
  templateUrl: './condition-list.component.html',
  styleUrls: ['./condition-list.component.css']
})
export class ConditionListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
