import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-request',
  templateUrl: './file-request.component.html',
  styleUrls: ['./file-request.component.css']
})
export class FileRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
