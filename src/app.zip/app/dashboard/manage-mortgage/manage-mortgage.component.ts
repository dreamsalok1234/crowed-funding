import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-mortgage',
  template: '<router-outlet><spinner></spinner></router-outlet>'
})
export class ManageMortgageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
