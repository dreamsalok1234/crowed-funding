import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mortgage-list',
  templateUrl: './mortgage-list.component.html',
  styleUrls: ['./mortgage-list.component.css']
})
export class MortgageListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
