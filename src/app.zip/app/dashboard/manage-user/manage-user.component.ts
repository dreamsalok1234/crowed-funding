import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-user',
  template: '<router-outlet><spinner></spinner></router-outlet>'
})
export class ManageUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
