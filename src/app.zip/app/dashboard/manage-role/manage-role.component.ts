import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-role',
  template: '<router-outlet><spinner></spinner></router-outlet>'
})
export class ManageRoleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
