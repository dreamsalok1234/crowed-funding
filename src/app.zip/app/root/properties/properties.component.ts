import { Component, OnInit } from '@angular/core';
import { PropertyService } from '../../_services/root/property.service';

@Component({
  selector: 'app-properties',
  templateUrl: './properties.component.html',
  styleUrls: ['./properties.component.css']
})
export class PropertiesComponent implements OnInit {
  loading = false;
  responseItem : any; 
  propertyList : any;
  constructor(private propertyService: PropertyService) { }
  ngOnInit() {
     this.getPropertyList();
  }
  getPropertyList() {
  		this.propertyService.getProperty().subscribe(
	      data => {
	      		
	         try {
	            this.responseItem  = data;
	          }
	          catch (error) {
	            this.responseItem  = "Something Wrong";
	          }          
	          if( typeof(this.responseItem) == 'object') 
	          	    this.propertyList = data.data;

	      },
	      error => {
	          
	          try {
	            this.responseItem  = JSON.parse(error._body);
	          }
	          catch (error) {
	            this.responseItem  = "Something Wrong";
	          }          
	          
	          this.loading = false;
	    });
  }
}
