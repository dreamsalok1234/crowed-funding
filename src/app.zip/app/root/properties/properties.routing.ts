import { Routes } from '@angular/router';
import {PropertiesComponent} from './properties.component';

export const PropertiesRoutes: Routes = [{
    path: '',
    component: PropertiesComponent,
    data: {
        breadcrumb: 'Properties'
    }
}];
